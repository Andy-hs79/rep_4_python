# 1. Создать классы + методы.
# Consumer(full_name, account,
#          prefer={"house_type": flat/house,
#                  "square": (int, int),
#                  "add_square": (int, int)}
#
# Shelter(price, square, flat/house, square_add)

# 2. Функции генерации объектов + аннотации:
# gen_house_objects(count: int) -> List[object(Shelter)]
# gen_consumer_object() -> object(Consumer)

# 3. Функция подбора:
# get_recommendations(List[object(Shelter)], object(Consumer))
#
# 4. Функции работы с excel. in and out

